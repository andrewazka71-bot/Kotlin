#!/bin/sh
./miner --algo octopus --server pool.eu.woolypooly.com:3094 --user cfx:aaketjh9tkj5g2k4zx3kfvb9vkku8nr956n0en4fhe --dalgo kheavyhash --dserver kas.2miners.com:2020 --duser kaspa:qrrzeucwfetuty3qserqydw4z4ax9unxd23zwp7tndvg7cs3ls8dvwldeayv5 --zilserver us1-zil.shardpool.io:3333 --ziluser zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
