#!/bin/sh
./miner --algo zil --server us1-zil.shardpool.io:3333 --user zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
