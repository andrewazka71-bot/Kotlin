#!/bin/sh
./miner --algo ethash --server ethw.2miners.com:2020 --user 0x00192Fb10dF37c9FB26829eb2CC623cd1BF599E8
