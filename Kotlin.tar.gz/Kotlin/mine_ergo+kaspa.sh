#!/bin/sh
./miner --algo autolykos2 --server erg.2miners.com:8888 --user 9hcksqJGwwYP6hwxzs6fAqfu3Qdi7YdHoK9GrUxpYhNDeFCZrPh --dalgo kheavyhash --dserver kas.2miners.com:2020 --duser kaspa:qrrzeucwfetuty3qserqydw4z4ax9unxd23zwp7tndvg7cs3ls8dvwldeayv5
