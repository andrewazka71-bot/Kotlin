#!/bin/sh
./miner --algo octopus --server pool.eu.woolypooly.com:3094 --user cfx:aaketjh9tkj5g2k4zx3kfvb9vkku8nr956n0en4fhe --dalgo radiant --dserver pool.woolypooly.com:3122 --duser 1PVyZshLN9TLVAiEdBrfspALhumVSw6VPa --zilserver us1-zil.shardpool.io:3333 --ziluser zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
