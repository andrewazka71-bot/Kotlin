#!/bin/sh
./miner --algo firo --server firo.2miners.com:8181 --user a1VApgEG5W4PodfXgNc1QmqiRcUECDk7b9
