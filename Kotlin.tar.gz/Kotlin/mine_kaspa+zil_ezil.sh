#!/bin/sh
./miner --algo kheavyhash --server kas.2miners.com:2020 --user kaspa:qrrzeucwfetuty3qserqydw4z4ax9unxd23zwp7tndvg7cs3ls8dvwldeayv5 --zilserver eu.ezil.me:4444 --ziluser 0x321ae4016a6397ee004b3f5f9e6c0a0c1915a05d.zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
