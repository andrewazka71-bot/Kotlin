#!/bin/sh
./miner --algo kawpow --server stratum-eu.rplant.xyz:7029 --user NYmTUxqqRbFg2XC3swbjXy9Gsu6EMetBWa
