#!/bin/sh
./miner --algo vds --server vds.666pool.com:9338 --user VcgLqxHev2XpG7ZZNXuFoyTnS9QYFWb96Ko
