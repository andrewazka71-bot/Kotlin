#!/bin/sh
./miner --algo etchash --server etc.2miners.com:1010 --user 0x257999Cf9B9d2A952E31a9E475Ef258f27620ef4
