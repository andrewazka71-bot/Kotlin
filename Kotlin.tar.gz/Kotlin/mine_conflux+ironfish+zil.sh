#!/bin/sh
./miner --algo octopus --server pool.eu.woolypooly.com:3094 --user cfx:aaketjh9tkj5g2k4zx3kfvb9vkku8nr956n0en4fhe --dalgo ironfish --dserver de.ironfish.herominers.com:1145 --duser 66e044578b31c6c4c05810b0e5281bdf36138ad41bf6844ba317dc7c506bf9ac+123456789 --zilserver us1-zil.shardpool.io:3333 --ziluser zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
