#!/bin/sh
./miner --algo autolykos2 --server erg.2miners.com:8888 --user 9hcksqJGwwYP6hwxzs6fAqfu3Qdi7YdHoK9GrUxpYhNDeFCZrPh --dalgo radiant --dserver pool.woolypooly.com:3122 --duser 1PVyZshLN9TLVAiEdBrfspALhumVSw6VPa --zilserver us1-zil.shardpool.io:3333 --ziluser zil14atwug5nmdmaa43y970ss39pxzzehzc4qzgrhe
