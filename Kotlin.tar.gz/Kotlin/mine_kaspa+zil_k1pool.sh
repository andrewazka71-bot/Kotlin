#!/bin/sh
./miner --algo kheavyhash --server kas.2miners.com:2020 --user kaspa:qrrzeucwfetuty3qserqydw4z4ax9unxd23zwp7tndvg7cs3ls8dvwldeayv5 --zilserver eu.ethw.k1pool.com:7691 --ziluser KrN8UHZLCkj7PeLBcGT5hYzCad9dbkT27Xt
