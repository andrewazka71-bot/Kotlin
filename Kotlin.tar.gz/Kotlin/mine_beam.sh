#!/bin/sh
./miner --algo beamhash --ssl 1 --server beam.2miners.com:5252 --user 3d88c373c094715c3d08caea4eb04374ce83a24ba6cfe88fc7739d307a4ed962ec
