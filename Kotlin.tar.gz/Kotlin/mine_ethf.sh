#!/bin/sh
./miner --algo ethash --server etf.f2pool.com:6688 --user 0x454fbd7501381f7d8c95e0ebf923ca3d11e04ef6
